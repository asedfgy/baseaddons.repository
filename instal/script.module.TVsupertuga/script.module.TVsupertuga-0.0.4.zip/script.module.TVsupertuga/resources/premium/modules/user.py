import base64 as b

id   = b.b64decode('c2NyaXB0Lm1vZHVsZS5UVnN1cGVydHVnYQ==')

name = b.b64decode('W0NPTE9SIGZmZmYwMDAwXVBST0pFQ1QgQVBPQ0FMWVBTRS0zMDRbL0NPTE9SXQ==')

host = b.b64decode('aHR0cDovL3R2c3VwZXJ0dWdhLnh5ei9wcmVtaXVt')

port = b.b64decode('MTQ0MDA=')