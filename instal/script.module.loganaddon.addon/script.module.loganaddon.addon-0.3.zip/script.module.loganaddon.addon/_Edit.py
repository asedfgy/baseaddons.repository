import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cHM6Ly9nb28uZ2wvblVvdGNy')
addon = xbmcaddon.Addon('script.module.loganaddon.addon')