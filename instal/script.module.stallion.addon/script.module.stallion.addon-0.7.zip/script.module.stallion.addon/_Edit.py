import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3R2c3VwZXJ0dWdhLnR2c3VwZXJ0dWdhLndlYnNpdGUvTU9CRFJPLmh0bWw=')
addon = xbmcaddon.Addon('script.module.stallion.addon')