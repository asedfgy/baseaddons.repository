import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2JsYWNrZ2hvc3RhZGRvbi9ncmF5L21hc3Rlci9saXN0LnhtbA==')
addon = xbmcaddon.Addon('script.module.adryan.addon')